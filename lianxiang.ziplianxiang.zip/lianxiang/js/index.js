var headerCenter = document.getElementById("headerCen");
var headerRight = document.getElementById("headerRig");
var headerIndex = document.getElementById("header-Ind");
var hIRight = document.getElementsByClassName("hIRight")[0];
var centerWithin = document.getElementsByClassName("centerWithin")[0];
var centerOuter = document.getElementsByClassName("centerOuter")[0];
var liOuterBJ = document.getElementsByClassName("liOuterBJ");
var LiWithin = document.getElementsByClassName("LiWithin");
// var LiOuterImg = document.getElementsByClassName("LiOuterImg");
var centerWithinLi = document.getElementsByClassName("centerWithin")[0].getElementsByTagName("li");
headerCenter.onclick = function() {
    headerRight.className = "headerRight header-right-btn";
    headerIndex.className = "header-Index header-Index-btn";
}
hIRight.onclick = function() {
    headerRight.className = "headerRight";
    headerIndex.className = "header-Index";
}

// 矩阵取值
function getTranslate(node, sty) { //获取transform值
    var translates = document.defaultView.getComputedStyle(node, null).transform.substring(7);
    var result = translates.match(/\(([^)]*)\)/); // 正则()内容
    var matrix = result ? result[1].split(',') : translates.split(',');
    if (sty == "rotate") {
        return matrix.length > 6 ? getRotate([parseFloat(matrix[0]), parseFloat(matrix[1]), parseFloat(matrix[4]), parseFloat(matrix[5])]) : getRotate(matrix);
    }
}

function getRotate(matrix) {
    var aa = Math.round(180 * Math.asin(matrix[0]) / Math.PI);
    var bb = Math.round(180 * Math.acos(matrix[1]) / Math.PI);
    var cc = Math.round(180 * Math.asin(matrix[2]) / Math.PI);
    var dd = Math.round(180 * Math.acos(matrix[3]) / Math.PI);
    var deg = 0;
    if (aa == bb || -aa == bb) {
        deg = dd;
    } else if (-aa + bb == 180) {
        deg = 180 + cc;
    } else if (aa + bb == 180) {
        deg = 360 - cc || 360 - dd;
    }
    return deg >= 360 ? 0 : deg;
}
// 矩阵取值


// 定时器轮播
var i = 36,
    a = 0,
    Out = 360,
    int;

(function() {
    int = window.setInterval("fun1()", 3000);
})();

// 定时器事件
function fun1() {
    centerWithin.style.transform = "rotate(" + i + "deg)";
    i += 36;
    if (a > 0) {
        for (var b = 0; b < 10; b++) {
            liOuterBJ[b].className = "liOuterBJ";
            LiWithin[b].className = "LiWithin";
        }
        // liOuterBJ[a].className = "liOuterBJ";
        liOuterBJ[a - 1].className = "liOuterBJ liOuterBJon";
        // LiWithin[a].className = "LiWithin";
        LiWithin[a - 1].className = "LiWithin LiWithinOn";
        a--;
    } else {
        for (var b = 0; b < 10; b++) {
            liOuterBJ[b].className = "liOuterBJ";
            LiWithin[b].className = "LiWithin";
        }
        // liOuterBJ[a].className = "liOuterBJ";
        // LiWithin[a].className = "LiWithin";
        a = 9
        liOuterBJ[a].className = "liOuterBJ liOuterBJon";
        LiWithin[a].className = "LiWithin LiWithinOn";
    }
    centerOuter.style.transform = "rotate(" + Out + "deg)";
    Out += 360;
    console.log("i" + i);
    // LiWithin[].style.transform = "rotate(0deg)";
}

// 绑定事件
for (var j = 0; j < 10; j++) {
    // console.log(j);
    centerWithinLi[j].onclick = (function(j) {
        return function() {
            var lival = getTranslate(centerWithinLi[j], "rotate"); //点击元素的角度值
            var s = getTranslate(centerWithin, "rotate"); //整个轮盘的角度值
            console.log(lival);
            centerWithin.style.transform = "rotate(" + (-lival) + "deg)";
            // if (j > 4) {
            //     centerWithin.style.transform = "rotate(" + (lival - 180) + "deg)";
            // } else {
            //     centerWithin.style.transform = "rotate(" + (-lival) + "deg)";
            // }
            for (var b = 0; b < 10; b++) {
                liOuterBJ[b].className = "liOuterBJ";
                LiWithin[b].className = "LiWithin";
            }

            liOuterBJ[j].className = "liOuterBJ liOuterBJon";
            LiWithin[j].className = "LiWithin LiWithinOn";

            window.clearInterval(int);
            // if (j > 5 || j == 0) {
            //     i = (360 - lival);
            //     console.log(360 - lival)
            // } else {
            //     i = 36 - lival;
            // }

            // function fun2() {
            a = j, i = 36 - lival;
            int = window.setInterval("fun1()", 3000);
            // }
            // fun2();


            // liOuterBJ[a].className = "liOuterBJ";
            // if (j > 0) {
            //     liOuterBJ[j].className = "liOuterBJ liOuterBJon";
            //     liOuterBJ[a].className = "liOuterBJ";
            // } else {
            //     liOuterBJ[j].className = "liOuterBJ";
            //     // a = 9
            //     liOuterBJ[j].className = "liOuterBJ liOuterBJon";
            // }
        }
    })(j)
}


// 点击旋转算法1
// var withintitle;
// for (var c = 0; c < 10; c++) {
//     if (liOuterBJ[c].className == "liOuterBJ liOuterBJon") {
//         withintitle = centerWithinLi[c].title;
//     }
// }
// if (j - withintitle >= 4) {
//     centerWithin.style.transform = "rotate(" + (lival - 180) + "deg)";
// } else {
//     centerWithin.style.transform = "rotate(" + (-lival) + "deg)";
// }

// 鼠标滚轮事件
var instat = 0,
    die;
window.onmousewheel = function(e) {
    clearInterval(int);
    e = window.event;
    if (e.wheelDelta > 0) {
        instat -= 36;
        centerWithin.style.transform = "rotate(" + instat + "deg)";
        if (a < 9) {
            for (var b = 0; b < 10; b++) {
                liOuterBJ[b].className = "liOuterBJ";
                LiWithin[b].className = "LiWithin";
            }
            liOuterBJ[a + 1].className = "liOuterBJ liOuterBJon";
            LiWithin[a + 1].className = "LiWithin LiWithinOn";
            a++;
        } else {
            for (var b = 0; b < 10; b++) {
                liOuterBJ[b].className = "liOuterBJ";
                LiWithin[b].className = "LiWithin";
            }
            a = 0
            liOuterBJ[a].className = "liOuterBJ liOuterBJon";
            LiWithin[a].className = "LiWithin LiWithinOn";
        }
    }
    if (e.wheelDelta < 0) {
        instat += 36;
        centerWithin.style.transform = "rotate(" + instat + "deg)";
        if (a > 0) {
            for (var b = 0; b < 10; b++) {
                liOuterBJ[b].className = "liOuterBJ";
                LiWithin[b].className = "LiWithin";
            }
            liOuterBJ[a - 1].className = "liOuterBJ liOuterBJon";
            LiWithin[a - 1].className = "LiWithin LiWithinOn";
            a--;
        } else {
            for (var b = 0; b < 10; b++) {
                liOuterBJ[b].className = "liOuterBJ";
                LiWithin[b].className = "LiWithin";
            }
            a = 9
            liOuterBJ[a].className = "liOuterBJ liOuterBJon";
            LiWithin[a].className = "LiWithin LiWithinOn";
        }
    }
    int = window.setInterval("fun1()", 3000);
}